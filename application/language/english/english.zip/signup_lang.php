<?php

$lang['register_message'] ='Form Register';