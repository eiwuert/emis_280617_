<?php
$lang['user_permission'] = 'User Permission';
$lang['user_permission_new'] = 'New';