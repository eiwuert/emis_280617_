<?php
$lang['professors'] = 'Professors';
$lang['professors_id'] = 'Professors ID';
$lang['professors_new'] = 'New Professor';
$lang['professors_update'] = 'Update Professor';
$lang['professors_basic_information'] = 'Professor Basic Information';
$lang['professors_successful_deleted']=' deleted';
$lang['professors_one_or_multiple']='professors(s)';
$lang['professors_cannot_be_deleted']='Could not deleted selected professor, one or more of the professor has processed sales or you are trying to delete yourself :)';
$lang['professors_cannot_delete_default_user'] = 'You cannot delete the default user';
$lang['professors_confirm_delete']='Are you sure to delete selected professor(s)?';
$lang['professors_none_selected']='You have not selected any professors to delete';