<?php $this->load->view("partial/header"); ?>
<div class=" alert alert-info" id='top'>
<?php echo create_breadcrumb(); ?>                                      
 </div>
 
 <?php $this->load->view("students/_update_academic"); ?>
    
<?php $this->load->view("partial/footer"); ?>