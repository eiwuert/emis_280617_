<div class="tab-pane" id="academic">
	<div class="row">
	  	<div class="col-xs-12 col-md-12 col-lg-12">
			<h2 class="page-header">
				<i class="fa fa-info-circle"></i> <?php echo lang("students_academic_details"); ?>	<div class="pull-right">
					<button type="button" class="btn btn-info btn-sm" data-toggle="modal" data-target="#studentAcedmic"><i class="fa fa-plus"></i> 
						<?php echo lang('students_new_academic'); ?>
					</button>
				</div>
			</h2>
		</div><!-- /.col -->
	</div>

	<div class="row academic-rows">
		<?php echo $items_academic; ?>
	</div>
</div>

<!-- Modal -->
<div class="modal fade" id="studentAcedmic" tabindex="-1" role="dialog" aria-labelledby="studentAcedmicLabel">
	<div class="modal-dialog" role="document">
		<div class="modal-content">
			<?php echo form_open("$controller_name/save_stu_academic", array('id' => 'stu_academic_form', 'class' => 'form-horizontal1')); ?>
			<div class="modal-header">
				<button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
				<h4 class="modal-title" id="studentAcedmicLabel"><?php echo lang('students_new_academic'); ?></h4>
			</div>
			<div class="modal-body">
				<div class="row">
					<div class="form-group required">
						<?php echo form_label(lang('common_major') . ':', 'majors', array('class' => 'control-label col-sm-4 col-md-4 col-lg-4')); ?>
						<div class="col-sm-8 col-md-8 col-lg-5">
							<?php
							echo form_dropdown('majors', $major, '', 'class="form-control" id="majors"');
							echo form_hidden('stu_info_id', $person_info->stu_info_id);
							?>
						</div>
					</div>
					<div class="form-group required">
						<?php echo form_label(lang('common_course') . ':', 'course_ids', array('class' => 'control-label col-sm-4 col-md-4 col-lg-4')); ?>
						<div class="col-sm-8 col-md-8 col-lg-5">
							<?php
							echo form_dropdown('course_ids', $courses, '', 'class="form-control" id="course_ids"');
							?>
						</div>
					</div>
					<div class="form-group required">
						<?php echo form_label(lang('common_status') . ':', 'acad_status', array('class' => 'control-label col-sm-4 col-md-4 col-lg-4')); ?>
						<div class="col-sm-8 col-md-8 col-lg-5">
							<?php
							$status = [
								'' => lang('common_select'),
								'D' => 'D',
								'C' => 'C',
								'W' => 'W'
							];
							echo form_dropdown('acad_status', $status, '', 'class="form-control" id="acad_status"');
							?>
						</div>
					</div>
					<div class="form-group required">
						<?php echo form_label(lang('students_admission_date') . ':', 'admission_date', array('class' => 'control-label col-sm-4 col-md-4 col-lg-4')); ?>
						<div class="col-sm-8 col-md-8 col-lg-5">
							<span class="input-group date " data-date-format="dd-mm-yyyy" data-date="">
								<input type="text" id="admission_date" class="form-control hasDatepicker" name="admission_date" size="10" placeholder="dd-mm-yyyy" data-format="DD-MM-YYYY" data-years="1990-2235" data-lang="en" value="">
								<span class="input-group-addon">
									<i class="fa fa-calendar"></i>
								</span>
							</span>
							<div class="errorTxt"></div>
							<br/>
						</div>
					</div>
					<div class="form-group">
						<?php echo form_label(lang('students_completion_date') . ':', 'completion_date', array('class' => ' col-sm-4 col-md-4 col-lg-4')); ?>
						<div class="col-sm-8 col-md-8 col-lg-5">
						<span class="input-group date " data-date-format="dd-mm-yyyy" data-date="">
							<input type="text" id="completion_date" class="form-control hasDatepicker" name="completion_date" size="10" placeholder="dd-mm-yyyy" data-format="DD-MM-YYYY" data-years="1990-2235" data-lang="en" value="">
							<span class="input-group-addon">
								<i class="fa fa-calendar"></i>
							</span>
						</span>
						<div class="errorTxt"></div>
						<br/>
						</div>
					</div>
				</div>
			</div>
			<div class="modal-footer">
			    <button type="button" class="btn btn-default" data-dismiss="modal"><?php echo lang('common_close'); ?></button>
			    <button type="submit" class="btn btn-primary"><?php echo lang('common_save'); ?></button>
			</div>
			<?php echo form_close(); ?>
		</div>
	</div>
</div>

<!-- JavaScript -->
<script type="text/javascript">
	$(document).ready(function(){
		initDatePicker("input[name='admission_date']");
		initDatePicker("input[name='completion_date']");
		$('body').on('change', '#majors', function(e) {
			e.preventDefault();
			var val = $(this).val(),
			url = SITE_URL + "students/get_major_course";
			$.ajax({
				url: url,
				type: 'POST',
				data: {major_id: val},
				dataType: 'json',
				success: function(result) {
					$('#course_ids').html(result.courses);
				}
				,error: function(res){console.log(res.responseText)}
			});
		});
		initDatePicker("#created_at");
		initDatePicker("#updated_at");
		setTimeout(function(){$(":input:visible:first", "#stu_academic_form").focus(); }, 100);
		$('#stu_academic_form').validate({
			submitHandler:function(form)
			{
				doAcademicSubmit(form);
			},
			errorClass: "text-danger",
			errorElement: "span",
			highlight:function(element, errorClass, validClass) {
				$(element).parents('.form-group').removeClass('has-success').addClass('has-error');
			},
			unhighlight: function(element, errorClass, validClass) {
				$(element).parents('.form-group').removeClass('has-error').addClass('has-success');
			},
			rules:
			{
				majors: "required",
				course_ids: "required",
				admission_date: "required",
			},
			messages:
			{
				majors: <?php echo json_encode(lang('students_major_is_required')); ?>,
				course_ids: <?php echo json_encode(lang('students_course_is_required')); ?>,
				admission_date: <?php echo json_encode(lang('students_addmission_date_is_required')); ?>,
			}
		});

		$('body').on('click', 'a.update-row-academic', function(e){
			e.preventDefault();
			$(this).parents('div.academic-row').addClass('focused');
			var url = $(this).data('href'),
			major_id = $(this).data('major'),
			course_id = $(this).data('course'),
			acad_status = $(this).data('acad-status'),
			admission_date = $(this).data('admission-date'),
			completion_date = $(this).data('completion-date');
			$('form#stu_academic_form').attr('action', url);
			$('select#majors').val(major_id);
			$('select#course_ids').val(course_id);
			$('select#acad_status').val(acad_status);
			$('input[name="admission_date"]').val(admission_date);
			$('input[name="completion_date"]').val(completion_date);
		});
	});

	var submitting = false;
	function doAcademicSubmit(form)
	{
		if (submitting) return;
		submitting = true;
		$(form).ajaxSubmit({
			success:function(response)
			{
				submitting = false;
				$.notify(response.success ? <?php echo json_encode(lang('common_success')); ?> + ' #' + response.stu_acad_id : <?php echo json_encode(lang('common_error')); ?>, response.message, response.success ? 'success' : 'error')
				if (response.success)
				{
					if ($('div.academic-row').hasClass('focused')) {
						$('div.academic-row.focused').replaceWith(response.items_academic);
					} else {
						$('.academic-rows').append(response.items_academic);
					}
					$('#studentAcedmic').modal('hide');
				}
			},
			error:function(response){console.log(response.responseText)},
			dataType:'json'
		});
	}
</script>