<table class="table table-bordered">
	<thead>
		<tr>
			<th><?php echo lang('students_skill'); ?></th>
			<th><?php echo lang('students_skill').lang('common_kh'); ?></th>
			<th><?php echo lang('students_changed_date'); ?></th>
			<th><?php echo lang('common_remark'); ?></th>
		</tr>
	</thead>
	<tbody>
		<?php
		foreach ($transfer_majors as $row) { ?>
			<tr>
				<td><?php echo H($row->skill_name); ?></td>
				<td><?php echo H($row->skill_name_kh); ?></td>
				<td><?php echo date(get_date_format(), strtotime($row->changed_date)); ?></td>
				<td><?php echo $row->remark; ?></td>
			</tr>
		<?php
		}
		?>
	</tbody>
</table>